<?php
/**
 * @file
 * Contains \Drupal\custom_site_location\Plugin\Block\csrFormBlock.
 */
namespace Drupal\custom_site_location\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormInterface;
use Drupal\Core\Form\FormStateInterface;
/**
 * Provides a 'Get location time' block.
 *
 * @Block(
 *   id = "get_location_time",
 *   admin_label = @Translation("Get location time"),
 *   category = @Translation("Custom block")
 * )
 */
class setLocationTimeBlock extends BlockBase {
  /**
   * {@inheritdoc}
   */
  public function build() {
    $manager = \Drupal::service('custom_site_location.get_site_location');
  	$data = $manager->getTimebyLocation();

    return [
    	'#theme' => 'my-template',
    	'#data' => $data,	
    	'#cache' =>[
    		'tags' => [
    			'node_list'
    		],
    	]
    ];
   }
}
