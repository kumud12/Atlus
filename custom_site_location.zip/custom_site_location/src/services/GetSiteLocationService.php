<?php

namespace Drupal\custom_site_location\services;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\DepedencyInjecton\Container;


/**
* class GetSiteLocationService().
*
* @package Drupal\custom_site_location
*/

class GetSiteLocationService {
	
	public function getTimebyLocation()
	{
		$finalTime = '';

		$config = \Drupal::config('custom_site_location.admin_settings');
		$timezone_value = $config->get('site_timezone');

		$date = new DateTime("now", new DateTimeZone($timezone_value) );
		$finalTime = $date->format('jS M Y h:i A');
		return $finalTime;
	}
}

