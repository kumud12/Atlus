<?php

namespace Drupal\custom_site_location\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Defines a form that configures custom_site_location’s settings.
 */
class SiteLocationForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'custom_site_location_admin_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'custom_site_location.admin_settings',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('custom_site_location.admin_settings');
    $form['site_country'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Country'),
      '#default_value' => $config->get('site_country'),
    ];
    $form['site_city'] = [
      '#type' => 'textfield',
      '#title' => $this->t('City'),
      '#default_value' => $config->get('site_city'),
    ];
    $form['site_timezone'] = [
      '#title' => t('Timezone'),
      '#type' => 'select',
      '#description' => 'Select Timezone',
      '#default_value' => $config->get('site_timezone'),
      '#options' => array(
                           t('--- SELECT ---'), 
                           t('America/Chicago'), 
                           t('America/New_York'), 
                           t('Asia/Tokyo'), 
                           t('Asia/Dubai'), 
                           t('Asia/Kolkata'), 
                           t('Asia/Amsterdam'), 
                           t('Asia/Oslo'), 
                           t('Asia/London'), 
                         ),
     ];

      return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->config('custom_site_location.admin_settings')
      ->set('site_country', $form_state->getValue('site_country'))
      ->set('site_city', $form_state->getValue('site_city'))
      ->set('site_timezone', $form_state->getValue('site_timezone'))
      ->save();
    parent::submitForm($form, $form_state);
  }

}